from django.db import models
from django.urls import reverse
from django.conf import settings
from django.utils import timezone
from django.contrib.auth.models import AbstractUser
# from django_autoslug.fields import AutoSlugField
from django.contrib.auth import get_user_model
from django_extensions.db.fields import AutoSlugField
import datetime

class CustomUser(AbstractUser):
    email = models.EmailField("email address", max_length=200, blank=True, null=True)
    phone = models.CharField("phone", max_length=200, blank=True, null=True)
    state = models.CharField("state", max_length=200, blank=True, null=True)
    city = models.CharField("city", max_length=200, blank=True, null=True)
    profile_image = models.ImageField(upload_to='profile/', blank=True, null=True)
    date = models.DateField(default=datetime.datetime.today, blank=True, null=True)

    def __str__(self):
        return self.email
    

class Categoery(models.Model):
    name = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return self.name
    
class Tag(models.Model):
    name = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return self.name


class Post(models.Model):
    author = models.ForeignKey(CustomUser, on_delete=models.CASCADE, blank=True, null=True)
    category = models.ForeignKey(Categoery, on_delete=models.CASCADE, blank=True, null=True)
    tags = models.ManyToManyField(Tag, blank=True)
    title = models.CharField(null=False, max_length=200, db_index=True)
    slug = AutoSlugField(populate_from='title', unique=True)
    text = models.TextField()
    feature_image = models.ImageField(upload_to='blog/', blank=True, null=True)
    thumbnail_image = models.ImageField(upload_to='blog/', blank=True, null=True)
    created_date = models.DateTimeField(default=timezone.now)
    published_date = models.DateTimeField(blank=True, null=True)

    def publish(self):
        self.published_date = timezone.now()
        self.save()
        

    def __str__(self):
        return self.title  


class Comment(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField(max_length=200)
    content = models.TextField(null=True)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add=True)
    # author = models.ForeignKey(get_user_model() , on_delete=models.CASCADE)
    parent = models.ForeignKey('self' , null=True , blank=True , on_delete=models.CASCADE , related_name='replies')

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return 'Comment by {}'.format(self.name)
    

    def __str__(self):
        return str(self.author) + ' comment ' + str(self.name)

    @property
    def children(self):
        return Comment.objects.filter(parent=self).reverse()

    @property
    def is_parent(self):
        if self.parent is None:
            return True
        return False

