from django.urls import path
from . import views
# from .views import signup, log_in, log_out
from blog.views import signup, log_in, log_out, edit_profile

urlpatterns = [
    path('', views.post_list, name='post_list'),
    path('filter/<int:id>', views.post_filter, name='post_filter'),
    path('filter-tag/<int:id>', views.post_filter_tag, name='post_filter_tag'),
    path('post/<str:slug>', views.post_detail, name='post_detail'),
    path('post/new/', views.post_new, name='post_new'),
    path('post/<int:pk>/edit/', views.post_edit, name='post_edit'),
    path('signup/', signup, name='signup'),
    path('login/', log_in, name='login'),
    path('logout/', log_out, name='logout'),

    path('profile/', views.profile, name='profile'),
    path('edit_profile/', views.edit_profile, name='edit_profile'),
    
]