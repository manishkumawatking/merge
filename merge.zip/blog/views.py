from django.shortcuts import render, get_object_or_404, redirect
from django.utils import timezone
from .models import Post, Comment, Categoery, Tag
from blog.models import CustomUser
from django.contrib.auth import login, authenticate, logout
from django.urls import reverse
from .forms import SignUpForm, LogInForm, PostForm, EditProfileForm, CommentForm
from django.http import HttpResponse
from .resources import PostResource
from django.contrib.auth.decorators import login_required

from rest_framework import viewsets
from .serializers import PostSerializer, CategoerySerializer, TagSerializer, UserSerializer


class UserViewSet(viewsets.ModelViewSet):
    queryset = CustomUser.objects.all()
    serializer_class = UserSerializer
    # permission_classes = [permissions.IsAuthenticated]

class PostList(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    serializer_class = PostSerializer

class CategoeryList(viewsets.ModelViewSet):
    queryset = Categoery.objects.all()
    serializer_class = CategoerySerializer

class TagList(viewsets.ModelViewSet):
    queryset = Tag.objects.all()
    serializer_class = TagSerializer




def post_filter(request, id):
    cate_filter = Post.objects.filter(category__id=id).all
    print('444444',cate_filter)
    return render(request, 'post_filter.html', {'cate_filter':cate_filter})

def post_filter_tag(request, id):
    tag_filter = Post.objects.filter(tags__id=id).all
    print('444444',tag_filter)
    return render(request, 'blog/post_filter_tag.html', {'tag_filter':tag_filter})
     

def post_list(request):
    posts = Post.objects.filter(published_date__lte=timezone.now()).order_by('published_date')
    return render(request, 'blog/post_list.html', {'posts': posts})


# def post_detail(request, pk):
#     post = get_object_or_404(Post, pk=pk)
#     return render(request, 'blog/post_detail.html', {'post': post})


def post_detail(request, slug):
    post = get_object_or_404(Post, slug=slug)
    comments = Comment.objects.filter(post=post)
    # print(comments, '1111111111111111111')
    if request.method == "POST":
        form = CommentForm(request.POST)
        if form.is_valid():
            try :
                parent = request.POST.get('comment_id')
                parent = Comment.objects.filter(id = parent).last()
                print(parent, 'parent instanceeeee')
            except:
                parent=None
            comments = form.save(commit=False)
            comments.post = post
            comments.parent = parent
            comments.save()
        return redirect('blog:post_detail', slug=post.slug)
    else:
        form  = CommentForm()
    return render(request, 'blog/post_detail.html', {'post': post,'form':form,'comment':comments})


def post_new(request):
    if request.method == "POST":
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.published_date = timezone.now()
            post.save()
            post.tags.set(form.cleaned_data['tags'])
            return redirect('post_detail', slug=post.slug)
    else:
        form = PostForm()
    return render(request, 'blog/post_edit.html', {'form': form})


def post_edit(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == "POST":
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.published_date = timezone.now()
            post.save()
            post.tags.set(form.cleaned_data['tags'])
            return redirect('post_detail', slug=post.slug)
    else:
        form = PostForm(instance=post)
    return render(request, 'blog/post_edit.html', {'form': form})


@login_required
def edit_profile(request):
    if request.method == "POST":
        form = EditProfileForm(request.user.username,
                               request.POST, request.FILES)
        if form.is_valid():
            # about_me = form.cleaned_data["about_me"]
            username = form.cleaned_data["username"]
            email = form.cleaned_data["email"]
            phone = form.cleaned_data["phone"]
            state = form.cleaned_data["state"]
            city = form.cleaned_data["city"]
            profile_image = form.cleaned_data["profile_image"]

            user = CustomUser.objects.get(id=request.user.id)
            print("10000000", user)
            # profile = CustomUser.objects.get(user=user)
            user.username = username
            user.email = email
            user.phone = phone
            user.state = state
            user.city = city
            print("You Here", user)
            user.save()
            print("You Here", user)
            return redirect("edit_profile", username=user.username)
    else:
        form = EditProfileForm(request.user.username)
    return render(request, "blog/edit_profile.html", {'form': form})

# def edit_profile(request, pk):
#     user = CustomUser.objects.get(pk=pk)
#     print(user)
#     if request.method == "POST":
#         form = SignUpForm(request.POST, instance=user)
#         print(form)
#         if form.is_valid():
#             user = form.save(commit=False)
#             user.author = request.user
#             user.published_date = timezone.now()
#             user.save()
#             return redirect('edit_profile', pk=Post.pk)
#     else:
#         form = SignUpForm(instance=user)
#     return render(request, 'blog/edit_profile.html', {'form': form})


def profile(request):
    return render(request,'profile.html')


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST) 
        # print(form)
        if form.is_valid():
            user = form.save()
            print(user)
            login(request, user)
            return redirect('blog/login.html')
    else:
        form = SignUpForm()  
        # print(form) 
    return render(request, 'blog/signup.html', {'form': form})
    


def log_in(request):
    error = False
    if request.user.is_authenticated:
        return redirect('/')
    if request.method == "POST":
        form = LogInForm(request.POST)
        # print(form)
        if form.is_valid():
            username = form.cleaned_data["username"]
            # print(email, '@@@@@@@@@@@@@@@@@@@@@@')
            password = form.cleaned_data["password"]
            # print(password, '@@@@@@@@@@@@@@@@@@@@@@')
            user = authenticate(username=username, password=password)
            # print(user, "you here")
            # print(form)
            if user is not None: 
                # print(user, "you here")
                login(request, user)  
                print(login, "you here")
                return redirect('/')
                
            else: 
                error = True
            # print("you here",login)
    else:
        form = LogInForm()
        # print(form)

    return render(request, 'blog/login.html', {'form': form, 'error': error})


def log_out(request):
    logout(request)
    return redirect(reverse('blog:login'))

def export(request):
    person_resource = PostResource()
    dataset = person_resource.export()
    response = HttpResponse(dataset.csv, content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="post.csv"'
    return response