from django.contrib import admin
from . import models
from .models import Post, CustomUser, Categoery, Tag, Comment
from import_export.admin import ImportExportModelAdmin
from django.conf import settings



# @admin.register(Post)
class PostAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    list_display = ['title', 'category']
    list_filter = ('tags', 'created_date', 'category')
    search_fields = ('title',)
    filter_horizontal = ('tags',)
    autocomplete_fields = ["category"]

class AdminCustomUser(admin.ModelAdmin):
    list_display = ['username', 'email']
    search_fields = ('username',)

class AdminCategoery(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ('name',)

class AdminTag(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ('name',)

class AdminComment(admin.ModelAdmin):
    list_display = ['post','name', 'email']
    search_fields = ('email',)

admin.site.register(Post, PostAdmin)
admin.site.register(Comment, AdminComment)
admin.site.register(Tag, AdminTag)
admin.site.register(Categoery, AdminCategoery)
admin.site.register(CustomUser, AdminCustomUser)