from django.contrib.auth.models import Group
from .models import CustomUser
from rest_framework import serializers
from django.shortcuts import render , redirect , HttpResponseRedirect
from blog.models import Post, Categoery, Tag
import requests

class PostSerializer(serializers.ModelSerializer):
  class Meta:
    model = Post
    fields = '__all__'


class CategoerySerializer(serializers.ModelSerializer):
  class Meta:
    model = Categoery
    fields = '__all__'

class TagSerializer(serializers.ModelSerializer):
  class Meta:
    model = Tag
    fields = '__all__'


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['url', 'username', 'email', 'phone', 'state','city', 'profile_image', 'date']