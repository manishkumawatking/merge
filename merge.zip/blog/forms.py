from django.contrib.auth.forms import UserCreationForm
from django import forms
from .models import CustomUser, Post, Comment
from .resources import PostResource
from django.utils.translation import gettext_lazy as _

class PostForm(forms.ModelForm):

    class Meta:
        model = Post
        fields = ('category', 'title', 'text', 'tags' , 'feature_image', 'thumbnail_image')

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ('name', 'email', 'content')

class SignUpForm(UserCreationForm):
    class Meta:
        model = CustomUser
        print(model)
        fields = ("first_name", "last_name", "username", "email", "phone", "state", "city", "profile_image", "date")

class LogInForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)


class EditProfileForm(forms.Form):
    username = forms.CharField()
    email = forms.EmailField()
    phone = forms.CharField()
    state = forms.CharField()
    city = forms.CharField()
    # about_me = forms.CharField(widget=forms.Textarea())
    profile_image = forms.ImageField(required=False)

    def __init__(self, original_username, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.original_username = original_username

    def clean_username(self):
        """
        This function throws an exception if the username has already been 
        taken by another user
        """

        username = self.cleaned_data['username']
        if username != self.original_username:
            if CustomUser.objects.filter(username=username).exists():
                raise forms.ValidationError(
                    'A user with that username already exists.')
        return username


person_resource = PostResource()
dataset = person_resource.export()
dataset.csv


