
from django.contrib import admin
from django.urls import path, include
from django.views.generic.base import TemplateView
from django.conf import settings
from django.conf.urls.static import static
from rest_framework import routers
from blog import views

router = routers.DefaultRouter()
router.register(r'users', views.UserViewSet)
router.register(r'blog-api', views.PostList)
router.register(r'categoery-api', views.CategoeryList)
router.register(r'tag-api', views.TagList)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('blog.urls')),
    path('polls/', include("polls.urls")),
    path('', TemplateView.as_view(template_name='post_list.html'), name='post_list'),
    path('blog/', include(('blog.urls', 'blog'), namespace='blog')),

    path('', include(router.urls)),
    path('api/',include(router.urls)),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework')),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) 

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
